
// server.js
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const fs = require('fs-extra');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({
  origin: ['http://localhost:3000'], // ajustar conforme frontend
  credentials: true
}));
app.use(bodyParser.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'troque_para_uma_coisa_secreta',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,   // importante: cookie não acessível via JS
    secure: false,    // true em produção com HTTPS
    maxAge: 1000 * 60 * 60 // 1 hora
  }
}));

const DB_FILE = path.join(__dirname, 'db.json');

// Inicializa DB simples
async function readDB(){
  const exists = await fs.pathExists(DB_FILE);
  if(!exists) {
    await fs.writeJson(DB_FILE, {codigosPremiados: [], codigosUsados: []}, {spaces:2});
  }
  return fs.readJson(DB_FILE);
}
async function writeDB(data){
  return fs.writeJson(DB_FILE, data, {spaces:2});
}

// Middleware para proteger rotas
function requireAuth(req, res, next){
  if (req.session && req.session.authenticated) return next();
  res.status(401).json({error: 'Não autenticado'});
}

// Rota de login (POST)
app.post('/api/login', async (req, res) => {
  const { user, pass } = req.body;
  const adminUser = process.env.ADMIN_USER;
  const adminPassHash = process.env.ADMIN_PASS_HASH; // bcrypt hash
  if (!adminUser || !adminPassHash) return res.status(500).json({error:'Servidor mal configurado'});

  if (user !== adminUser) return res.status(401).json({error:'Usuário ou senha incorretos'});

  const ok = await bcrypt.compare(pass, adminPassHash);
  if (!ok) return res.status(401).json({error:'Usuário ou senha incorretos'});

  // sucesso: cria sessão
  req.session.authenticated = true;
  req.session.user = adminUser;
  res.json({ok:true});
});

// Logout
app.post('/api/logout', (req, res) => {
  req.session.destroy(err => {
    res.json({ok:true});
  });
});

// Rota para verificar código (pode ser usada pelo público)
app.post('/api/verificar', async (req, res) => {
  const { codigo } = req.body;
  if (!codigo) return res.status(400).json({error:'Código é obrigatório'});
  const db = await readDB();
  const code = codigo.trim().toUpperCase();

  if (db.codigosUsados.includes(code)) {
    return res.json({status:'usado'});
  }
  if (db.codigosPremiados.includes(code)) {
    // marca como usado
    db.codigosUsados.push(code);
    await writeDB(db);
    return res.json({status:'ganhou'});
  }
  return res.json({status:'nao'});
});

// Rotas admin (protegidas)
app.get('/api/admin/codigos', requireAuth, async (req, res) => {
  const db = await readDB();
  res.json({codigosPremiados: db.codigosPremiados, codigosUsados: db.codigosUsados});
});

app.post('/api/admin/adicionar', requireAuth, async (req, res) => {
  const { novoCodigo } = req.body;
  if (!novoCodigo) return res.status(400).json({error:'Código é obrigatório'});
  const code = novoCodigo.trim().toUpperCase();
  const db = await readDB();
  if (!db.codigosPremiados.includes(code)) {
    db.codigosPremiados.push(code);
    await writeDB(db);
  }
  res.json({ok:true});
});

app.post('/api/admin/apagar-usados', requireAuth, async (req, res) => {
  const db = await readDB();
  db.codigosUsados = [];
  await writeDB(db);
  res.json({ok:true});
});

app.post('/api/admin/limpar-tudo', requireAuth, async (req, res) => {
  const db = await readDB();
  db.codigosPremiados = [];
  db.codigosUsados = [];
  await writeDB(db);
  res.json({ok:true});
});

// Servir frontend se quiser (ex: build estático)
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
