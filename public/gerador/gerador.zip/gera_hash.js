// gera_hash.js
const bcrypt = require('bcrypt');
const pass = process.argv[2];

if (!pass) {
  console.error('Uso: node gera_hash.js SuaSenhaAqui');
  process.exit(1);
}

bcrypt.hash(pass, 10).then(hash => {
  console.log('HASH GERADO:');
  console.log(hash);
}).catch(err => {
  console.error(err);
});