let articles = [];
let currentPage = 1;
const perPage = 12;

async function loadArticles(){
  const res = await fetch("data.json");
  articles = await res.json();
  renderPage();
}

function getPagedArticles(list){
  const start = (currentPage - 1) * perPage;
  return list.slice(start, start + perPage);
}

function renderPage(){
  const filtered = doSearch(true);
  const paged = getPagedArticles(filtered);
  renderArticles(paged);
  renderPagination(filtered.length);
}

function renderPagination(total){
  const totalPages = Math.ceil(total / perPage);
  const pager = document.getElementById("pager");
  pager.innerHTML = "";

  for(let i=1; i<=totalPages; i++){
    const b = document.createElement("button");
    b.textContent = i;
    if(i === currentPage) b.classList.add("active");
    b.onclick = ()=>{ currentPage = i; renderPage(); };
    pager.appendChild(b);
  }
}

function renderArticles(list){
  const results = document.getElementById("results");
  const empty = document.getElementById("empty");

  results.innerHTML = "";

  if(!list.length){
    empty.style.display = "block";
    return;
  }

  empty.style.display = "none";

  list.forEach(a=>{
    const card = document.createElement("div");
    card.className = "card";

    card.innerHTML = `
      <div class="hero" style="background-image: url('${a.image}')"></div>
      <div class="body">
        <div class="meta">${a.date} • ${a.category}</div>
        <h3>${a.title}</h3>
        <p>${a.excerpt}</p>
        <button class="btn" onclick="window.location='noticia.html?id=${a.id}'">Ler matéria</button>
      </div>
    `;

    results.appendChild(card);
  });
}

let filterCategory = "all";

function doSearch(returnData){
  const q = document.getElementById("searchInput").value.trim().toLowerCase();

  const filtered = articles.filter(a=>{
    if(filterCategory !== "all" && a.category !== filterCategory) return false;
    if(!q) return true;

    return (a.title + a.excerpt + a.content).toLowerCase().includes(q);
  });

  if(!returnData) renderArticles(filtered);
  return filtered;
}

document.querySelectorAll(".chip").forEach(ch=>{
  ch.onclick = ()=>{
    filterCategory = ch.dataset.filter;
    renderPage();
  };
});

document.getElementById("searchInput").oninput = ()=> doSearch();

loadArticles();
