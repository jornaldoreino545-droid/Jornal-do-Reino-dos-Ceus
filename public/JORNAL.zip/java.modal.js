    const closeModal = document.getElementById("closeModal");
    const overlay = document.getElementById("overlay");

    // Abre o modal automaticamente ao carregar a página
    window.addEventListener("load", () => {
      overlay.classList.add("active");
    });

    // Fecha clicando no "X"
    closeModal.addEventListener("click", () => {
      overlay.classList.remove("active");
    });

    // Fecha clicando fora do modal
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) {
        overlay.classList.remove("active");
      }
    });