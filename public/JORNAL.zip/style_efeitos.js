gsap.registerPlugin(ScrollTrigger)

const elem = document.querySelector('.effecs-contan');

const cards = document.querySelector('.effect')

gsap.to(".effect", {
    opacity: 1, 
    duration: 1,
    scrollTrigger: {
        trigger: ".effect",
        start:"top center",
        end: "bottom center",
        toggleActions:"restart",
        scrub: true
    }
})

const jornalConteudo = document.querySelector('.sobreojornal')

gsap.to(".sobreojornal", {
    opacity: 1,
    duration: 1,
    scrollTrigger: {
        trigger: ".sobreojornal",
        start:"top center",
        end: "200px center",
        toggleActions:"restart",
        scrub: true,
    }
})

const igrejaConteudo = document.querySelector('.quemsomosfundo')

gsap.to(".quemsomosfundo", {
    opacity: 1,
    duration: 1,
    scrollTrigger: {
        trigger: ".quemsomosfundo",
        start: "top center",
        end: "100px center",
        toggleActions:"restart",
        scrub: true,
    }

})

const cardResponsaveis = document.querySelector('.todoselementos')

gsap.to(".todoselementos", {
    opacity: 1,
    y: -100,
    duration: 1,
    scrollTrigger: {
        trigger: ".todoselementos",
        start:"-100px center",
        end: "100px center",
        toggleActions: "restart",
        scrub: true,
    }
})



